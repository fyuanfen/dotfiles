#!/bin/zsh

# WARP DIRECTORY
# ==============
# oh-my-zsh plugin
#
# @github.com/mfaerevaag/wd

wd() {
    . $ZSH/plugins/wd/wd.sh
}
